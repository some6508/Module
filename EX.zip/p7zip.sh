# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

	ui_print "----------------------------"
	ui_print "   正在安装文件..."
	sleep 1
	cp -rf $TMPDIR/7z /sbin/.magisk/busybox/ || ui_print "   [✘]安装7z文件失败"
	cp -rf $TMPDIR/7za /sbin/.magisk/busybox/ || ui_print "   [✘]安装7za文件失败"
	cp -rf $TMPDIR/7zr /sbin/.magisk/busybox/ || ui_print "   [✘]安装7zr文件失败"
	cp -rf $TMPDIR/7z.so /system/lib64/ || ui_print "   [✘]安装7z.so文件失败"
	cp -rf $TMPDIR/zip /sbin/.magisk/busybox/ || ui_print "   [✘]安装zip文件失败"
	chmod 777 /sbin/.magisk/busybox/*
	chmod 777 /system/lib64/7z.so
if [ -f /system/lib64/7z.so ] && [ -f /sbin/.magisk/busybox/7z ] && [ -f /sbin/.magisk/busybox/7za ] && [ -f /sbin/.magisk/busybox/7zr ] && [ -f /sbin/.magisk/busybox/zip ]; then
ui_print "   [✔]安装文件成功"
	var_p7zip=true
else
	ui_print "   [✘]安装文件失败"
fi