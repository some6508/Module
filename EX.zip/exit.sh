# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

set -x
	[ -d $MODULEROOT/* ] || rm -rf $MODULEROOT && rm -rf $MODPATH/$MODID
	[ -d $MODUIES/$MODID/system ] || rm -rf $MODUIES/$MODID
	[ -f $MODUIES/$MODID/update ] && rm -rf $MODUIES/$MODID/update && rm -rf $MODUIES/$MODID/module.prop && mv $MODUIES/$MODID/module.prop.bak $MODUIES/$MODID/module.prop || rm -rf $MODUIES/$MODID/module.prop.bak
set +x
run_time
	ui_print "----------------------------"