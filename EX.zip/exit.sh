# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

set -x
	rm -rf $MODUIES_UPDATE/$MODID
	[ -d $MODUIES_UPDATE/* ] || rm -rf $MODUIES_UPDATE
	[ -d $MODUIES/$MODID/system ] || rm -rf $MODUIES/$MODID
	[ -f $MODUIES/$MODID/update ] && rm -rf $MODUIES/$MODID/update && rm -rf $MODUIES/$MODID/module.prop && mv $MODUIES/$MODID/module.prop.bak $MODUIES/$MODID/module.prop || rm -rf $MODUIES/$MODID/module.prop.bak
	ui_print "----------------------------"