# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

if [ $THEME == true ]; then
$DEBUG_FLAG && ui_print "调试：</MIUI_Theme_Values>..."
for i in com.android.systemui com.android.settings com.miui.player com.miui.securitycenter com.miui.weather2 framework-res; do
	echo "</MIUI_Theme_Values>" >> $TMPDIR/mods/theme/$i/theme_fallback.xml
	echo "</MIUI_Theme_Values>" >> $TMPDIR/mods/theme/$i/nightmode/theme_fallback.xml
	echo "</MIUI_Theme_Values>" >> $TMPDIR/mods/theme/$i/theme_values.xml
	echo "</MIUI_Theme_Values>" >> $TMPDIR/mods/theme/$i/nightmode/theme_values.xml
	cd $TMPDIR/mods/theme/$i
	[ `awk 'END{print NR}' theme_fallback.xml` -le 3 ] && rm -f theme_fallback.xml
	[ `awk 'END{print NR}' nightmode/theme_fallback.xml` -le 3 ] && rm -f nightmode/theme_fallback.xml
	[ `awk 'END{print NR}' theme_values.xml` -le 3 ] && rm -f theme_values.xml
	[ `awk 'END{print NR}' nightmode/theme_values.xml` -le 3 ] && rm -f nightmode/theme_values.xml
	if [ -f theme_fallback.xml ] || [ -f nightmode/theme_fallback.xml ] || [ -f theme_values.xml ] || [ -f nightmode/theme_values.xml ]; then
		$DEBUG_FLAG && ui_print "调试：zip_theme_files：*.xml..."
		zip -r $MODPATH/system/media/theme/default/$i ./* >/dev/null
	fi
done
	cp -rf $MODPATH/system/media/theme/default/framework-res.zip $TMPDIR/framework-res
	cp -rf $INSTALLER/framework-res $MODPATH/system/media/theme/default/
	rm -rf $MODPATH/system/media/theme/default/framework-res.zip
fi