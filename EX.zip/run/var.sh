# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0


var_sdk="`grep_prop ro.*version.sdk`"
var_name="`grep_prop ro.*version.name`"
var_brand="`grep_prop ro.product.*brand`"
var_model="`grep_prop ro.product.*model`"
var_device="`grep_prop ro.product.*device`"
var_release="`grep_prop ro.*version.release`"
var_version="`grep_prop ro.*version.incremental`"
var_manufacturer="`grep_prop ro.product.*manufacturer`"

base() { $1 $2 | base64 -d && $1; }
if [ -f "$MODUIES/$MODID/module.prop" ]; then
[ -f $MODUIES/$MODID/module.prop.bak ] || cp -rf $MODUIES/$MODID/module.prop $MODUIES/$MODID/module.prop.bak
version_1="(已安装版本：$VERSION_1)"
fi