# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0


brand="Xiaomi"
if [ "$var_brand" != "$brand" ] && [ "$var_manufacturer" != "$brand" ]; then
	ui_print "[$name]不支持您的手机：[$var_brand]，只支持[$brand]。"
	source $RUN/exit.sh
	exit
fi