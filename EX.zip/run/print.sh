# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

ui_print "----------------------------"
ui_print "  模块名称：$MODNAME"
ui_print "  模块作者：$AUTHOR"
ui_print "  模块版本：$VERSION $version_1"
ui_print "  需要加入新功能联系：$AUTHOR"
ui_print "----------------------------"
ui_print "  设备型号：$var_model ($var_device)"
ui_print "  系统版本：$var_name $var_version"
ui_print "  设备版本：$var_release (SDK$var_sdk)"
ui_print "----------------------------"
base ui_print LSDlh7rnjrBidWfor7fngrnlh7vlj7PkuIrop5Lkv53lrZhsb2cKLSDlj5Hnu5nphbflrolA6JGj5bCP6LGq