# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

	ui_print "----------------------------"
	ui_print "   正在安装解压程序..."
	cp -rf $TMPDIR/zip /sbin/.magisk/busybox/ || ui_print "   [✘]安装解压程序失败"
	chmod 777 /sbin/.magisk/busybox/zip
if [ -f /sbin/.magisk/busybox/zip ]; then
	var_zip=true
	ui_print "   [✔]安装解压程序成功"
else
	var_zip=true
	ui_print "   [✘]安装解压程序失败"
fi
run_time