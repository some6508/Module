# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

	ui_print "  更新日志："
	ui_print "----------------------------"
cat $TMPDIR/mods/log/"$VERSION".log|sed -e 's/*//g;s/`//g;s/#//g;s/ →.*//g'
	ui_print "----------------------------"
	ui_print "   [音量+]：继续安装"
	ui_print "   [音量-]：退出安装"
if $VOLKEY_FUNC; then
	ui_print "  已选择[继续安装]"
run_time
else
	ui_print "   已选择[退出安装]"
sleep 1
	source $TMPDIR/exit.sh
	exit
fi