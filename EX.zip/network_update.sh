# 脚本底包: 来自酷安@巴啦啦魔仙女王
# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

update_switch=true
update_remind=true
	echo true | grep -q $update_switch
	if [ $? -eq 0 ]; then
		var_a="接受网络更新"
		echo true | grep -q $update_remind
		if [ $? -eq 0 ]; then
			ui_print "----------------------------"
			ui_print "  是否接受模块在每次开机后通过网络自动检查更新"
			ui_print "   [音量+]：[$var_a]"
			ui_print "   [音量-]：[不$var_a]"
			if $VOLKEY_FUNC; then
				ui_print "   已选择[$var_a]"
				cp -rf $TMPDIR/update_service.sh /data/adb/service.d/$MODID
				chmod 0755 /data/adb/service.d/$MODID
			else
				var_a="不接受网络更新"
				ui_print "   已选择[$var_a]"
				[ -f /data/adb/service.d/$MODID ] && rm -rf /data/adb/service.d/$MODID
			fi
		else
			ui_print "   已选择[$var_a]"
			cp -rf $TMPDIR/update_service.sh /data/adb/service.d/$MODID
			chmod 0755 /data/adb/service.d/$MODID
		fi
	else
		var_a="不接受网络更新"
		ui_print "   已选择[$var_a]"
		[ -f /data/adb/service.d/$MODID ] && rm -rf /data/adb/service.d/$MODID
	fi
	[ -f /data/adb/service.d/$MODID ] && sed -i 's#urlurlurlurlurl#'$UPDATE_URL'#g' /data/adb/service.d/$MODID
	run_time