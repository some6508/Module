# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v1.0
# 更新日期: 2020-02-27 13:24

# 安装时显示的模块名称
mod_name=""
# 功能来源
SOURCE=""
# 模块介绍
mod_install_desc="主题！。$SOURCE"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装[$mod_name]"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_name]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装[$mod_name]"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""
# 支持的设备，支持正则表达式(多的在后面加上|)
mod_require_device=".{0,}" #全部
# 支持的系统版本，持正则表达式
mod_require_version=".{0,}" #全部
# 支持的设备版本，持正则表达式
mod_require_release=".{0,}" #全部


mod_install_yes()
{

#theme ""

return 0

}

mod_install_no() 
{

return 0

}
