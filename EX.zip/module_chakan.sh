# 脚本底包: 来自酷安@QG真心
# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

ID() {
for module_id in $(ls)
do
if [ ! "$module_id" = "$MODID" ]; then
	let id++
	module_name=$(cat $module_id/module.prop | grep 'name')
	module_author=$(cat $module_id/module.prop | grep 'author')
	module_description=$(cat $module_id/module.prop | grep 'description')
	ui_print "----------------------------"
	ui_print "  $id.$module_id"
	ui_print "    名称：${module_name:5}"
	ui_print "    作者：${module_author:7}"
	ui_print "    简介：${module_description:12}"
	if [ -e "$module_id/system/etc/hosts" ]; then
		ui_print "----------------------------"
		ui_print "  此模块已安装相关内容"
		ui_print "    Hosts功能："
		ui_print "    1.AD-Hosts"
		var_hosts=true
		ui_print "----------------------------"
		ui_print "  请按下 [任意音量键] 继续"
		$VOLKEY_FUNC
	fi
	if [ -e "$module_id/system/media/bootanimation.zip" ]; then
		ui_print "----------------------------"
		ui_print "  此模块已安装相关内容"
		ui_print "    开机动画功能："
		ui_print "    1.小米害怕开机动画"
		ui_print "    2.龙猫转呼啦圈开机动画"
		var_bootanimation=true
		ui_print "----------------------------"
		ui_print "  请按下 [任意音量键] 继续"
		$VOLKEY_FUNC
	fi
THEME="/system/media/theme/default"
	if [ -e "$module_id/$THEME/com.android.systemui" ] && [ -e "$module_id/$THEME/com.miui.home" ] && [ -d "$module_id/system/vendor/etc/camera" ] && [ -e "$module_id/$THEME/com.miui.screenrecorder" ] && [ -e "$module_id/$THEME/powermenu" ] && [ -e "$module_id/$THEME/com.miui.securitycenter" ] && [ -e "$module_id/$THEME/framework-res" ] && [ -e "$module_id/$THEME/com.android.settings" ]; then
		ui_print "----------------------------"
		ui_print "  此模块已安装相关内容"
		ui_print "    系统UI功能："
		ui_print "    1.UI美化"
		ui_print "    2.相机水印"
		ui_print "    3.60帧录屏"
		ui_print "    4.高级重启"
		ui_print "    5.高级重启美化"
		ui_print "    6.去除游戏网络提速界面"
		ui_print "    7.小横条沉浸"
		ui_print "    8.单手模式、锁屏时间、动画缩放"
		var_ui=true
		ui_print "----------------------------"
		ui_print "  请按下 [任意音量键] 继续"
		$VOLKEY_FUNC
	fi
	if [ -e "$module_id/system/etc/device_features/$var_device.xml" ]; then
		ui_print "----------------------------"
		ui_print "  此模块已安装相关内容"
		ui_print "    特色功能："
		ui_print "    1.视频工具箱"
		ui_print "    2.双人脸录入"
		ui_print "    3.极致省电模式"
		ui_print "    4.游戏高能时刻"
		ui_print "    5.游戏变声器半成品"
		ui_print "    6.去除游戏网络提速界面"
		var_device_features=true
		ui_print "----------------------------"
		ui_print "  请按下 [任意音量键] 继续"
		$VOLKEY_FUNC
	fi
	if [ -e "$module_id/system/etc/audio_effects.conf" ] && [ -e "$module_id/system/vendor/etc/audio_effects.conf" ] && [ -e "$module_id/system/vendor/etc/audio_effects.xml" ]; then
		ui_print "----------------------------"
		ui_print "  此模块已安装相关内容"
		ui_print "    音效共存功能："
		ui_print "    1.ViPER4AndroidFX"
		ui_print "    2.添加到耳机音效"
		ui_print "    3.杜比音效立体声"
		ui_print "    4.音频向导"
		var_viper=true
		ui_print "----------------------------"
		ui_print "  请按下 [任意音量键] 继续"
		$VOLKEY_FUNC
	fi
	if [ -e "$module_id/system/framework/framework-res.apk" ]; then
		ui_print "----------------------------"
		ui_print "  此模块已安装相关内容"
		ui_print "    过渡动画动能："
		ui_print "    1.IOS过度动画"
		ui_print "    2.安卓Q、IOS过度动画"
		var_framework=true
		ui_print "----------------------------"
		ui_print "  请按下 [任意音量键] 继续"
		$VOLKEY_FUNC
	fi
fi
done
}

ui_print "  检测到您已安装以下模块："

cd $MODUIES/
ID
cd $MODULEROOT/
ID
run_time