# 脚本底包: 来自酷安@cjybyjk
# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0


theme() {
	cd $MOD_FILES_DIR/$2
	mkdir -p $MODPATH/system/media/theme/default
	cat add_theme_values.xml >> $TMPDIR/mods/theme/$1/theme_values.xml
	cat nightmode/add_theme_values.xml >> $TMPDIR/mods/theme/$1/nightmode/theme_values.xml
	zip -r $MODPATH/system/media/theme/default/$1 ./res >/dev/null
	zip -r $MODPATH/system/media/theme/default/$1 ./nightmode/res >/dev/null
}

installapk() {
	filelist=$(ls $1)
	for file in $filelist; do
		extension="${file##*.}"
		if [ "$extension" = "apk" ]; then
			ui_print "- 正在安装 $file..."
			sleep 1
			pm install -r "$1/$file" && ui_print "- [✔]安装$file成功" || ui_print "- [✘]安装$file失败"
		fi
	done
}

framework() {
	ui_print "- 正在安装过度动画..."
	sleep 1
	cp -r /system/framework/framework-res.apk $TMPDIR/framework-res.zip
	7za a $TMPDIR/framework-res.zip res/ >&2 && ui_print "- [✔]安装过度动画完成" || ui_print "- [✘]安装过度动画失败"
	cp -r $TMPDIR/framework-res.zip $MODPATH/system/framework/framework-res.apk
}


# 建议不要在模块安装过程中改动下列函数

# $1:prop_text
add_sysprop()
{
	echo "$1" >> $MODPATH/system.prop
}

# $1:path/to/file
add_sysprop_file()
{
	echo -e "# $mod_name：" >> $MODPATH/system.prop
	cat "$1" >> $MODPATH/system.prop
	echo -e "\n" >> $MODPATH/system.prop
}

# $1:path/to/file
add_service_sh()
{
	LATESTARTSERVICE=true
	cp "$1" $MODPATH/service_$MOD.sh
	chmod 0755 $MODPATH/service_$MOD.sh
}

# $1:path/to/file
add_postfsdata_sh()
{
	POSTFSDATA=true
	cp "$1" $MODPATH/post-fs-data_$MOD.sh
	chmod 0755 $MODPATH/post-fs-data_$MOD.sh
}

# $1:str
trim()
{
	local trimmed="$*"
	trimmed="${trimmed%% }"
	trimmed="${trimmed## }"
	echo "$trimmed"
}

# $1:ID of mod
check_mod_install()
{
	if [ "`echo $MODS_SELECTED_YES | egrep \($1\)`" != "" ]; then
			echo -n "yes"
			return 0
	elif [ "`echo $MODS_SELECTED_NO | egrep \($1\)`" != "" ]; then
			echo -n "no"
			return 0
	fi
	echo -n "未知"
}
