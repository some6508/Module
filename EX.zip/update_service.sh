#!/system/bin/sh
# 脚本底包: 来自酷安@巴啦啦魔仙女王
# 脚本编写: 酷安@董小豪
# 编写: 酷安@董小豪
# 版本: v2.0

until [ $(getprop sys.boot_completed) -eq 1 ]
do 
		sleep 2
done
echo "等待35秒" && sleep 35
mod_id=${0##*/}
MOD_ID=$$
path="/storage/emulated/0/"$mod_id".log"
mod_file="/data/adb/modules/$mod_id"
MOD_FILES="/storage/emulated/0/Download/"$mod_id"_update"
MOD_FILES_DIR="$MOD_FILES/mods/*/files"
MODPATH="/data/adb/modules_update/$mod_id"
config=$MOD_FILES/"$mod_id".txt
SH="/data/adb/service.d/$mod_id"
get_value() { sed -n "s|^$1=||p" $config; }

rm -rf $MOD_FILES/"$mod_id".log

[ ! -e $config ] && mkdir -p $MOD_FILES && echo "# $mod_id更新配置\n\nlog=off\n# 默认配置是: [log=off]\n# 是否开启显示脚本的运行过程(日志)，默认关闭\n# 随便输入其他，则开启\n\nsleep=10,1800\n# 默认配置是: [sleep=10,1800]\n# 意思是: 循环10次，每30分钟循环1次\n# 第一个表示: 要循环多少次就停止。不能小于1次\n# 第二个表示: 等待时间，以秒为单位。不能小于1秒\n\n# 要重新运行在终端输入: [su]和[sh $SH]\n# 要停止运行在终端输入: [su]和[kill -9 $MOD_ID]\n# 注意: [kill -9] 后面的数字每次运行在这里都会改变。" > $config
n=0;while(($n<=$(get_value sleep | cut -d, -f1)));do echo "\n[`date "+%F %T"`] 第$((n+1))次循环" && (( n++ ))
	[ ! -e $config ] && mkdir -p $MOD_FILES && echo "# $mod_id更新配置\n\nlog=off\n# 默认配置是: [log=off]\n# 是否开启显示脚本的运行过程(日志)，默认关闭\n# 随便输入其他，则开启\n\nsleep=10,1800\n# 默认配置是: [sleep=10,1800]\n# 意思是: 循环10次，每30分钟循环1次\n# 第一个表示: 要循环多少次就停止。不能小于1次\n# 第二个表示: 等待时间，以秒为单位。不能小于1秒\n\n# 要重新运行在终端输入: [su]和[sh $SH]\n# 要停止运行在终端输入: [su]和[kill -9 $MOD_ID]\n# 注意: [kill -9] 后面的数字每次运行在这里都会改变。" > $config
if [ ! -d "$mod_file" ];then
	echo "\n[`date "+%F %T"`] 模块不存在\n$mod_file"
	echo "\n[`date "+%F %T"`] 正在删除...\n$SH"
	rm -rf $0
	rm -rf $MOD_FILES
	echo "\n[`date "+%F %T"`] 正在停止运行..."
	kill -9 $MOD_ID
else
	rm -rf $MOD_FILES/*.bak
	[ "$(get_value log)" != "off" ] && set -x 2>>$MOD_FILES/"$mod_id".log
	echo "[`date "+%F %T"`] 第[$n]次"
	echo "[`date "+%F %T"`] 开始时间"
	echo "[`date "+%F %T"`] 进程ID: [$MOD_ID]"
	sed -i 's#kill -9 .*#kill -9 '$MOD_ID']#g' $config
	var=`sed -n 3p $mod_file/module.prop`
	mod_version=${var#*=}
#	iptables -F
	[ ! -f $path ]
	until [ $? -eq 1 ]
	do
		curl -L urlurlurlurlurl -o $path
		[ ! -f $path ]
	done
	grep "html" $path > /dev/null
	if [ $? -eq 1 ];then
		sed -i 's/\[.*\]//g' $path
		var_version=`sed -n 1p $path`
		var_force=`sed -n 2p $path`
		var_url=`sed -n 3p $path`
		rm -rf $path
		echo $mod_version | grep -q $var_version
		if [ $? -eq 0 ];then :
		else
			unzip -l $MOD_FILES/"$mod_id"-v"$var_version".zip
			if [ $? -eq 0 ];then
				sed -i 's/description.*/description=模块有新版本'$var_version'发布,非强制性更新,已自动下载至用户目录Download\/'$mod_id'_update下,有需要请自行刷入/g' $mod_file/module.prop
			else
				sed -i 's/description.*/description=模块有新版本'$var_version'发布,当前正在后台龟速下载中,下拉刷新模块列表更新进度信息/g' $mod_file/module.prop
				mkdir -p $MOD_FILES
				cd $MOD_FILES
				i=1
				curl -L $var_url -o ./"$mod_id"-v"$var_version".zip
				unzip -l ./"$mod_id"-v"$var_version".zip
				until [ $? -eq 0 ]
				do
					i=$((i + 1))
					sed -i 's/description.*/description=模块有新版本'$var_version'发布,当前正在后台龟速下载中,正在进行第'$i'下载,(这个下载命令很稳的，一般一次就能成功,若尝试若干次本条状态还没有更新,那可能是作者网址搞错了,请联系作者修改网址或关闭更新)下拉刷新模块列表更新进度信息/g' $mod_file/module.prop
					curl -L $var_url -o ./"$mod_id"-v"$var_version".zip
					unzip -l ./"$mod_id"-v"$var_version".zip
				done
				echo $var_force | grep -q off
				if [ $? -eq 0 ];then
					sed -i 's/description.*/description=模块有新版本'$var_version'发布,非强制性更新,已后台自动下载至Download\/'$mod_id'_update下,有需要请通过面具自行刷入/g' $mod_file/module.prop
				else
					sed -i 's/description.*/description=模块有新版本'$var_version'发布,强制性更新,当前已下载完成,正在后台安装,下拉刷新模块列表更新进度信息/g' $mod_file/module.prop
					unzip -o ./"$mod_id"-v"$var_version".zip -d ./
					. $MOD_FILES/common/update.sh
					rm -rf $MOD_FILES
					sed -i 's/description.*/description=模块有新版本'$var_version'发布,强制性更新,当前状态已经完成,请重启手机/g' $mod_file/module.prop
				fi
			fi
		fi
	fi
fi
echo "[`date "+%F %T"`] 结束时间\n"
for i in $(seq $(get_value sleep | cut -d, -f2) -1 1);do H=$(( $i /3600 )) && M=$(( $i %3600/60 )) && S=$(( $i %3600%60 )) && echo "\n[`date "+%F %T"`] 目前是第$n次循环\n[`date "+%F %T"`] 下次循环还剩$H小时$M分钟$S秒" && sleep 1;done
done