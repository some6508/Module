
var_sdk="`grep_prop ro.*version.sdk`"
var_name="`grep_prop ro.miui.ui.*name`"
var_model="`grep_prop ro.product.*model`"
var_device="`grep_prop ro.product.*device`"
var_release="`grep_prop ro.*version.release`"
var_version="`grep_prop ro.build.*incremental`"

print() { sed -n "s|^$1=||p" ${2:-$TMPDIR/module.prop} 2>/dev/null || :; }

author=$(print author)
name=$(print name)
version=$(print version)
versionCode=$(print versionCode)
