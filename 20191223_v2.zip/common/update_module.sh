
#自动更新需自行修改/common/update.sh   命令基本上都写完了，就剩一个文件名字自己填一下就行了
#https://github.com/some6508/some/raw/master/magisk_update_mod

#自动更新配置链接[每个/前必须打一个\否则无效,更新链接通过github自行免费注册(谷歌浏览器自带翻译),更新配置名字写模块的id,内容参照以下网址写,不要出现"html",模块压缩包名字和id不要出现中文,id保留小数点后1位]
update_url="https:\/\/github.com\/some6508\/allinone_template\/raw\/master\/$MODID"

#网络更新开关,true的时候打开网络更新，可以通过后期在github发布新版本
update_switch="true"
