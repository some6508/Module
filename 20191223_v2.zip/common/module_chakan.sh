cd /data/adb/modules/
for module_id in $(ls)
do
if [ ! "$module_id" = "$MODID" ];then
  let id++
  module_name=$(cat $module_id/module.prop | grep 'name')
  module_author=$(cat $module_id/module.prop | grep 'author')
  module_description=$(cat $module_id/module.prop | grep 'description')
  ui_print "*******************************"
  ui_print "  $id.$module_id"
  ui_print "    名称：${module_name:5}"
  ui_print "    作者：${module_author:7}"
  ui_print "    简介：${module_description:12}"
  if [ -e "$module_id/system/etc/hosts" ];then
    ui_print "*******************************"
    ui_print "  此模块已安装Hosts相关内容"
    ui_print "  将无法安装本模块以下功能："
    ui_print "    1.AD-Hosts"
    ui_print "    2.去服务，视频广告"
    ui_print "  请删除此修改模块后重试"
    var_hosts=true
    ui_print "*******************************"
    ui_print "  请按下 [任意音量键] 继续"
    $VOLKEY_FUNC
  fi
  if [ -e "$module_id/system/media/theme/default/com.android.systemui" ];then
    ui_print "*******************************"
    ui_print "  此模块已安装Hosts相关内容"
    ui_print "  将无法安装本模块以下功能："
    ui_print "    1.状态栏美化"
    ui_print "  请删除此修改模块后重试"
    var_systemui=true
    ui_print "*******************************"
    ui_print "  请按下 [任意音量键] 继续"
    $VOLKEY_FUNC
  fi
fi
done