# 安装时显示的模块名称
mod_name="网络更新"
# 模块介绍
mod_install_desc="网络更新模块"
# 安装时显示的提示
mod_install_info="是否接受$mod_name"
# 按下[音量+]选择的功能提示
mod_select_yes_text="接受$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[接受$mod_name]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不接受$mod_name"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc="[不接受$mod_name]"
# 支持的设备，支持正则表达式(多的在后面加上|)
mod_require_device="platina"
# 支持的系统版本，持正则表达式
mod_require_version="9.[0-30].[0-30]|9" #(9.0.30-9.0.30,9)


#网络更新提醒开关，true的时候刷入有提醒，用户通过音量键选择是否接受[true/false]
update_remind="true"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
#    mkdir -p $MODPATH/system
#    cp -r $MOD_FILES_DIR/system/* $MODPATH/system

    # 附加值到 system.prop
#    add_sysprop ""
    # 从文件附加值到 system.prop
#    add_sysprop_file $MOD_FILES_DIR/system.prop
    # 添加service.sh
#    add_service_sh $MOD_FILES_DIR/service.sh
    # 添加post-fs-data.sh
#    add_postfsdata_sh $MOD_FILES_DIR/post-fs-data.sh

    ui_print "    设置权限"
#    set_perm $MODPATH/system/* 0 0 0644
    
    
    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}

# 对权限的附加说明
# 只有一些特殊文件需要特定的权限
# 下面是 set_perm 函数的一些示例:

# set_perm_recursive  <目录>                <所有者> <用户组> <目录权限> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
# set_perm_recursive  $MODPATH/system/lib       0       0       0755        0644

# set_perm  <文件名>                         <所有者> <用户组> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
# set_perm  $MODPATH/system/bin/app_process32   0       2000      0755       u:object_r:zygote_exec:s0
# set_perm  $MODPATH/system/bin/dex2oat         0       2000      0755       u:object_r:dex2oat_exec:s0
# set_perm  $MODPATH/system/lib/libart.so       0       0         0644

