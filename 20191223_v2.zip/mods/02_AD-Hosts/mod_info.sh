# 安装时显示的模块名称
mod_name="AD-Hosts"
# 模块介绍
mod_install_desc="屏蔽各类广告包括(各大视频网站,运营商劫持广告,大部分APP广告)，hosts规则均来自于网络搜索和github及酷友提供，使用时请关闭其他hosts模块，18.0+请关闭systemless hosts模块(如果有)，18.0以下打开设置中的systemless hosts选项，如还有问题请卸载模块后重刷。>>>来自依然的爱的模块"
# 安装时显示的提示
mod_install_info="是否安装$mod_name"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_name]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""
# 支持的设备，支持正则表达式(多的在后面加上|)
mod_require_device=""
# 支持的系统版本，持正则表达式
mod_require_version="" #(9.0.30-9.0.30,9)

if [ $var_hosts = true ];then
    MOD_SKIP_INSTALL=true
fi

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
    mkdir -p $MODPATH/system/etc
    cp -r $MOD_FILES_DIR/system/etc/* $MODPATH/system/etc

    ui_print "    设置权限"
    set_perm $MODPATH/system/etc/hosts 0 0 0600
    
    var_installed="hosts1"
    
    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}

